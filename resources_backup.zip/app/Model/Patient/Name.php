<?php

namespace App\Model\Patient;

use Illuminate\Database\Eloquent\Model;

class Name extends Model
{
    //
}
