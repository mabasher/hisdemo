<?php

namespace App\Model\Patient;

use Illuminate\Database\Eloquent\Model;

class Registration extends Model
{
    protected $gurded = [];
    // protected $fillable = ['reg_no'];
}
