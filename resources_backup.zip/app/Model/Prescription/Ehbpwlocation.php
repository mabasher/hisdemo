<?php

namespace App\Model\Prescription;

use Illuminate\Database\Eloquent\Model;

class Ehbpwlocation extends Model
{
    //
}
