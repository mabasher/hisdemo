<?php

namespace App\Model\Pharmacy;

use Illuminate\Database\Eloquent\Model;

class Pminstruction extends Model
{
    //
}
