<?php

namespace App\Model\Setup;

use Illuminate\Database\Eloquent\Model;

class Division extends Model
{
    //
}
