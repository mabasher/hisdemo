<?php

namespace App\Model\Billing;

use Illuminate\Database\Eloquent\Model;

class Fninvoicemst extends Model
{
    protected $gurded = [];
}
