<?php

namespace App\Model\Billing;

use Illuminate\Database\Eloquent\Model;

class Fnpatledger extends Model
{
    protected $gurded = [];
}
