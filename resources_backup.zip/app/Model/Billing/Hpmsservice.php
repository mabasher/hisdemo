<?php

namespace App\Model\Billing;

use Illuminate\Database\Eloquent\Model;

class Hpmsservice extends Model
{
    //
}
