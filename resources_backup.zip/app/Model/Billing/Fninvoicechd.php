<?php

namespace App\Model\Billing;

use Illuminate\Database\Eloquent\Model;

class Fninvoicechd extends Model
{
    protected $gurded = [];
}
