<?php

namespace App\Pharmarcy;

use Illuminate\Database\Eloquent\Model;

class Ehsymptom extends Model
{
    //
}
