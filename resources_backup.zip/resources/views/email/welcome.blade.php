<html>
    <title>Welcome mail</title>
    <body>
        <h1>Welcome To Mail</h1>
        <p>Hello Everybody</p>
    </body>
</html>