@foreach($brands as $b)
<option value="{{$b->test_no}}">{{$b->test_name}}</option>
@endforeach