<!DOCTYPE html>
<html lang="en">

<head>
	<title>DTL</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>

    <p>{{$r->name}}</p>
  
    <input type="text" value="{{$r->phone}}" disabled>
    
    <p>{{$r->doctor}}</p>
    
</body>

</html>