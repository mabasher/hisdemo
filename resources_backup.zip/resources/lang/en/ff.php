<?php

return [

    'P' => 'Primary Consultation',
    'F' => 'Folow up',

];
