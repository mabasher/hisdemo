<?php

return [

    'dashboard' => 'Dashboard',
    'doctors' => 'Doctors',

];
 