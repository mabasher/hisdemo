<?php

return [

    'dashboard' => 'ড্যাসবোর্ড',
    'doctors' => 'ডাক্তার',

];
 