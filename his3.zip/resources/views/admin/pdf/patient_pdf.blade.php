<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>

<body>

	<h1>Registration Card</h1>
	<p>{{$regNo}}</p>
	<p>{{$name}}</p>
</body>

</html>