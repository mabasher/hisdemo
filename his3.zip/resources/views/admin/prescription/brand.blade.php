@foreach($brands as $b)
<option value="{{$b->id}}">{{$b->test_name}}</option>
@endforeach