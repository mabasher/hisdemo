<?php

namespace App\Model\Doctor;

use Illuminate\Database\Eloquent\Model;

class Specialization extends Model
{
    //
}
