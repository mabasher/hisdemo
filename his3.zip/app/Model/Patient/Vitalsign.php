<?php

namespace App\Model\Patient;

use Illuminate\Database\Eloquent\Model;

class Vitalsign extends Model
{
    protected $gurded = [];

}
