<?php

namespace App\Model\Doctor;


use Illuminate\Database\Eloquent\Model;

class Doctorvisit extends Model
{

}
