<?php

namespace App\Model\Prescription;

use Illuminate\Database\Eloquent\Model;

class Ehpatientexam extends Model
{
    //
}
