<?php

namespace App\Model\Billing;

use Illuminate\Database\Eloquent\Model;

class Fnpaymentdetail extends Model
{
    protected $gurded = [];
}
