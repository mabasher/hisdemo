<?php

namespace App\Model\Billing;

use Illuminate\Database\Eloquent\Model;

class Fnpaidmodeamt extends Model
{
    protected $gurded = [];
}
